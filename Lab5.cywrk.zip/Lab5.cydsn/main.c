#include "project.h"
#include <string.h>

#define PASSWORD_LENGTH 4
const char correct_password[PASSWORD_LENGTH + 1] = "1402"; 
char input_buffer[PASSWORD_LENGTH + 1] = {0};
uint8_t input_idx = 0;

#define SEG_BLANK  0xFF
#define SEG_MINUS  0xBF
#define SEG_P      0x8C
#define SEG_A      0x88
#define SEG_S      0x92
#define SEG_F      0x8E
#define SEG_I      0xF9
#define SEG_L      0xC7

// ВИПРАВЛЕНИЙ МАСИВ (Від 0 до 9)
const uint8_t DIGIT_MAP[12] = {
    0xC0, // [0] 0
    0xF9, // [1] 1
    0xA4, // [2] 2
    0xB0, // [3] 3
    0x99, // [4] 4
    0x92, // [5] 5
    0x82, // [6] 6
    0xF8, // [7] 7
    0x80, // [8] 8 (Було 0x90)
    0x90, // [9] 9 (Було 0x88)
    0x88, // [10] * (Символ A)
    0x83  // [11] # (Символ b)
};

uint8_t display_buf[8] = {SEG_BLANK, SEG_BLANK, SEG_BLANK, SEG_BLANK, 
                          SEG_BLANK, SEG_BLANK, SEG_BLANK, SEG_BLANK};

void SetLED(uint8_t r, uint8_t g, uint8_t b) {
    LED_R_Write(r);
    LED_G_Write(g);
    LED_B_Write(b);
}

void SendTo595(uint8_t data) {
    for(int8_t i = 0; i < 8; i++) {
        if (data & (0x80 >> i)) {
            Pin_DO_Write(1);  
        } else {
            Pin_DO_Write(0);  
        }
        Pin_CLK_Write(1);  
        Pin_CLK_Write(0);  
    }
}

void DisplayRefresh(void) {
    for (uint8_t i = 0; i < 8; i++) {
        SendTo595(0xFF & ~(1 << i)); 
        SendTo595(display_buf[i]);   
        
        Pin_Latch_Write(1);
        Pin_Latch_Write(0);
        
        CyDelay(2); 
    }
}

void DelayWithDisplay(uint32_t ms) {
    uint32_t loops = ms / 16;
    for(uint32_t i = 0; i < loops; i++) {
        DisplayRefresh();
    }
}

// НОВА ФУНКЦІЯ АНІМАЦІЇ (Рядок, що біжить)
void ScrollMessage(uint8_t c1, uint8_t c2, uint8_t c3, uint8_t c4, uint32_t duration_ms) {
    uint8_t msg[4] = {c1, c2, c3, c4};
    uint32_t elapsed = 0;
    uint32_t shift_interval = 250; // Зміщувати кожні 250 мс
    uint8_t offset = 0;            // Поточний зсув
    
    while (elapsed < duration_ms) {
        // 1. Очищаємо екран
        for(int i = 0; i < 8; i++) {
            display_buf[i] = SEG_BLANK;
        }
        
        // 2. Записуємо літери з урахуванням зсуву (по колу)
        for(int i = 0; i < 4; i++) {
            display_buf[(offset + i) % 8] = msg[i];
        }
        
        // 3. Показуємо цей "кадр" певний час
        DelayWithDisplay(shift_interval);
        elapsed += shift_interval;
        
        // 4. Рухаємо текст на 1 позицію вправо
        offset = (offset + 1) % 8; 
    }
}

char ScanKeypad(void) {
    char key = 0;

    C_1_Write(0); C_2_Write(1); C_3_Write(1); CyDelayUs(10);
    if (R_1_Read() == 0) key = '1';
    if (R_2_Read() == 0) key = '4';
    if (R_3_Read() == 0) key = '7';
    if (R_4_Read() == 0) key = '*';

    C_1_Write(1); C_2_Write(0); C_3_Write(1); CyDelayUs(10);
    if (R_1_Read() == 0) key = '2';
    if (R_2_Read() == 0) key = '5';
    if (R_3_Read() == 0) key = '8';
    if (R_4_Read() == 0) key = '0';

    C_1_Write(1); C_2_Write(1); C_3_Write(0); CyDelayUs(10);
    if (R_1_Read() == 0) key = '3';
    if (R_2_Read() == 0) key = '6';
    if (R_3_Read() == 0) key = '9';
    if (R_4_Read() == 0) key = '#';

    C_1_Write(1); C_2_Write(1); C_3_Write(1);

    return key;
}

void ClearSystem(void) {
    input_idx = 0;
    for(int i=0; i<8; i++) display_buf[i] = SEG_BLANK;
    SetLED(0, 0, 0); 
}

int main(void) {
    CyGlobalIntEnable; 
    SW_Tx_UART_Start();
    SW_Tx_UART_PutString("\r\n Liedge pas:\r\n");
    char key = 0;
    char last_key = 0;
    
    ClearSystem();
    for(;;) {
        key = ScanKeypad();
        if (key != 0 && last_key == 0) {
            
            if (key == '#') { 
                
                if (input_idx == PASSWORD_LENGTH && strncmp(input_buffer, correct_password, PASSWORD_LENGTH) == 0) {
                    SW_Tx_UART_PutString("\r\nACCESS_GRANTED\r\n");
                    
                    // Виклик анімації PASS на 5000 мс (5 секунд)
                    ScrollMessage(SEG_P, SEG_A, SEG_S, SEG_S, 5000);
                    
                    ClearSystem();         
                    
                } else {
                    
                    SW_Tx_UART_PutString("\r\nACCESS_DENIED\r\n");
                    
                    // Виклик анімації FAIL на 5000 мс (5 секунд)
                    ScrollMessage(SEG_F, SEG_A, SEG_I, SEG_L, 5000);
                    
                    ClearSystem();          
                }
                
            } else if (key == '*') { 
                ClearSystem();
            } else { 
                if (input_idx < PASSWORD_LENGTH) {
                    input_buffer[input_idx] = key;
                    display_buf[input_idx] = DIGIT_MAP[key - '0'];
                    input_idx++;
                    SW_Tx_UART_PutChar(key); 
                }
            }
        }
        
        last_key = key;

        DisplayRefresh();
    }
}