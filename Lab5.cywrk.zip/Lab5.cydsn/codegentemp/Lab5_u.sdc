# Component constraints for Y:\Psoc_Project\Lab5\Lab5\Lab5.cydsn\TopDesign\TopDesign.cysch
# Project: Y:\Psoc_Project\Lab5\Lab5\Lab5.cydsn\Lab5.cyprj
# Date: Fri, 27 Mar 2026 14:47:42 GMT
